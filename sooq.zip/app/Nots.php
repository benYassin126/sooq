<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Nots extends Model
{
    protected $fillable = [
        'Nots',
    ];
}
