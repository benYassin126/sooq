<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserDesign extends Model
{
    protected $fillable = [
        'TheImg','UserID',
    ];
}
