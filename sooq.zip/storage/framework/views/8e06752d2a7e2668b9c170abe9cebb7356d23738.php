<?php $__env->startSection('title','القوالب'); ?>
<?php $__env->startSection('content'); ?>


<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <!-- Strat MSG -->
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert" id="display-success">
     <strong><?php echo e(session()->get('success')); ?></strong>
     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
  <div class="alert-dismissible  alert alert-danger" id="display-success">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>
  <!-- End MSG -->


  <!-- Start Content -->

  <div class="row">

<div class="card card-info mt-4 mb-4">
   <div class="card-header">
    <h3 class="card-title">تفضل برفع   تصاميم القالب</h3>
</div>
<!-- /.card-header -->
<!-- form start -->

<form class="form-horizontal" action="<?php echo e(route('templateImg.store')); ?>" method="post" enctype="multipart/form-data">


<?php echo csrf_field(); ?>
<input type="hidden" name="TemplateID" value="<?php echo e(request()->TemplateID); ?>">
<div class="card-body">

  <div class="form-group">
    <label class="control-label">تصاميم القالب</label>
    <div>
     <input type="file" name="TheImg[]"  multiple="multiple" required />
  </div>
</div>

</div>




    <div class="card-footer">
  <button type="submit" class="btn btn-success btn-block">حفظ  التصاميم </button>

</div>


</form>
</div>
  </div>


  <!-- End Content -->

  <?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.adminLTE', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>