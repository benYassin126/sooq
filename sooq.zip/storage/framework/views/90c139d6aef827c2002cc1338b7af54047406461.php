<?php $__env->startSection('title','تعديل  قالب'); ?>

<?php $__env->startSection('content'); ?>

<!-- Main content -->
<div class="content">
  <div class="container-fluid">

    <!-- Strat MSG -->
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
     <strong><?php echo e(session()->get('message')); ?></strong>
     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
  <?php endif; ?>
  <!-- END MSG -->
  <?php if($errors->any()): ?>
  <div class="alert alert-danger">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>
  <!-- Strat MSG -->

  <div class="card card-info mb-4">
   <div class="card-header">
    <h3 class="card-title" style="display: inline-block;">تعديل  القالب  [ <?php echo e($thisTemplate->TemplateName); ?> ]</h3>
    <form method="Post" action="<?php echo e(route('template.destroy',$thisTemplate->id)); ?>" style="float: left;">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button onclick="return confirm('<?php echo e(__('هل انت متاكد ؟')); ?>')" class="btn btn-danger "><i class="fas fa-trash-alt"></i>  حذف القالب </buttn>
      </form>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form action="<?php echo e(route('template.update',$thisTemplate)); ?>" method="post" enctype="multipart/form-data">
      <?php echo method_field('PATCH'); ?>
      <?php echo $__env->make('admin.template._part._partFormAdd_Update', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


      <div class="card-footer">

        <button type="submit" name="update" class="btn btn-success btn-block"> <i class="fas fa-edit fa-sm"></i> حفظ التعديلات  </button>

      </div>


    </form>

    <!-- /.card-body -->

  </div>

  <!-- /.card -->




  <!-- Horizontal Form -->




  <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.adminLTE', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>