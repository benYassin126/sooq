<?php $__env->startSection('title','استخدام القالب'); ?>
<?php $__env->startSection('content'); ?>


<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <!-- Strat MSG -->
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert" id="display-success">
     <strong><?php echo e(session()->get('success')); ?></strong>
     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
  <div class="alert-dismissible  alert alert-danger" id="display-success">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>
  <!-- End MSG -->

  <!-- Start Content -->

  <!-- Srtat Form -->
  <div class="row">
    <div class="card card-info mt-4 mb-4">
     <div class="card-header">
      <h3 class="card-title">تفضل برفع الصور</h3>
      <br>
      <ul>
        <li>يجب ان لايتجاوز حجم الصورة الواحدة     <span class="right badge badge-danger">  5 جيجا بايت  </span></li>
        <li>الصيغ المسموح بها [ PNG , JPEG ,GIF,SVG ]</li>
      </ul>
    </div>
    <form class="form-horizontal" action="<?php echo e(route('template.useTemplate',$template->id)); ?>" method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="card-body">
        <div class="form-group">
          <label class="control-label ml-2">الصور المفرغة</label><span class="right badge badge-danger"><?php echo e(isset($countOFTransparent) ? $countOFTransparent : ''); ?></span><br>
          <p class="control-label ml-2">اذا كنت لا تملك صور مفرغة إليك هذه الأداة الرائعة</label><a href="https://www.remove.bg"><span class="right badge badge-danger">اضغط هنا لتفريغ الصور</p></a>
            <div>
             <input type="file" name="Transparent[]" required  multiple="multiple" />
           </div>
         </div>
         <div class="form-group">
          <label class="control-label ml-2">الصور البيئية</label><span class="right badge badge-danger"><?php echo e(isset($countOFWithBackGound) ? $countOFWithBackGound : ''); ?></span>
          <div>
           <input type="file" name="WithBackGound[]" required  multiple="multiple"  />
         </div>
       </div>

       <div class="form-group">
        <label class="control-label">اللون الأساسي لهوية العميل(Hex)</label> <span style="color: green">اختياري</span>
        <div>
         <input type="color" name="MineColor" value=<?php echo e($template->MineColor); ?>>
       </div>
     </div>

     <div class="form-group">
      <label class="control-label">اللون الثانوي لهوية العميل  (Hex)</label> <span style="color: green">اختياري</span>
      <div>
       <input type="color" name="SubColor" value=<?php echo e($template->SubColor); ?>>
     </div>
   </div>

   <div class="form-group">
    <label class="control-label">اللون الثانوي الاضافي لهوية العميل(Hex)</label>  <span style="color: green">اختياري</span>
    <div>
     <input type="color" name="SubSubColor" value=<?php echo e($template->SubSubColor); ?>>
   </div>
 </div>

</div>
<div class="card-footer">
  <button type="submit" class="btn btn-success btn-block">صمم الآن</button>
</div>
</form>
</div>
</div>
<!-- End Form -->

<!-- Start Show Template -->
<hr>
<h3 class="text-center mt-4 mb-4">تصميمك جاهز</h3>
<div class="MocUp text-center">
  <?php if(isset($allImgPath)): ?>
  <div class="marvel-device iphone-x">
    <div class="notch">
      <div class="camera"></div>
      <div class="speaker"></div>
    </div>
    <div class="top-bar"></div>
    <div class="sleep"></div>
    <div class="bottom-bar"></div>
    <div class="volume"></div>
    <div class="overflow">
      <div class="shadow shadow--tr"></div>
      <div class="shadow shadow--tl"></div>
      <div class="shadow shadow--br"></div>
      <div class="shadow shadow--bl"></div>
    </div>
    <div class="inner-shadow"></div>
    <div class="screen">
        <img style="width: 100%;height: 250px" src="/img/instMock.png">
      <?php $__empty_1 = true; $__currentLoopData = $allImgPath; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imgPath): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

      <img class="imgesInMockUp" src="/img/output/<?php echo e($imgPath); ?>.png">



      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <?php echo e('pre'); ?>

      <?php endif; ?>
    </div>
  </div>

  <?php endif; ?>
</div>

<!-- end Show Template -->



<!-- End Content -->


<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.adminLTE', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>