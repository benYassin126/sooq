<?php $__env->startSection('title','نظرة عامة'); ?>
<?php $__env->startSection('content'); ?>
<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <!-- Strat MSG -->
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert" id="display-success">
      <strong><?php echo e(session()->get('success')); ?></strong>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="alert-dismissible  alert alert-danger" id="display-success">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
    <!-- End MSG -->
    <!-- Start Content -->
    <br>
    <div class="TemplateInfo">
      <table class="table table-bordered">
        <thead>
          <tr class="table-info">
            <th scope="col">اسم القالب</th>
            <th scope="col">شكل القالب</th>
            <th scope="col">التحكم بالقالب</th>
          </tr>
          <tr>
            <th><?php echo e($thisTemplate->TemplateName); ?></th>
            <th><img src="<?php echo e(url('/admin/template/fetch_image')); ?>/ <?php echo e($thisTemplate->id); ?>" style="width: 150px"></th>
            <th> <a href="<?php echo e(route('template.edit',$thisTemplate->id)); ?>" class="btn btn-primary mb-4 ">تعديل بيانات القالب</a></th>
          </tr>
        </thead>
      </table>
    </div>
    <a href="<?php echo e(route('templateImg.create')); ?>?TemplateID=<?php echo e($thisTemplate->id); ?>" class="btn btn-success btn-block mb-4">إضافة  تصاميم القالب</a>
    <a href="<?php echo e(url('/admin/template')); ?>/<?php echo e($thisTemplate->id); ?>/useTemplate" class="btn btn-primary btn-block mb-4">استخدام القالب</a>
    <hr>
    <div class="allImg">
      <div class="row">

        <?php $__empty_1 = true; $__currentLoopData = $allImg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col col-6">
          <div class="card">
            <div class="card-body">
               <img class="img-responsive" src="<?php echo e(url('/admin/templateImg/fetch_image')); ?>/<?php echo e($img->id); ?>">
            </div>
            <div class="card-footer">
              <form  action="<?php echo e(route('templateImg.update',$img->id)); ?>" method="post" style="float: right;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <input type="radio" name="ImgType" value="Transparent" id="Transparent_<?php echo e($img->id); ?>"  <?php if($img->ImgType == 'Transparent'): ?> checked <?php endif; ?>>
                <label class="ml-4" for="Transparent_<?php echo e($img->id); ?>">مغرغ</label>
                <input type="radio" name="ImgType" value="WithBackGound" id="WithBackGound_<?php echo e($img->id); ?>"  <?php if($img->ImgType == 'WithBackGound'): ?> checked <?php endif; ?>>
                <label for="WithBackGound_<?php echo e($img->id); ?>">بيئي</label>
                <button type="submit" class="btn btn-success ">حفظ </button>
              </form>
              <form method="Post" action="<?php echo e(route('templateImg.destroy',$img->id)); ?>" style="float: left;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button  onclick="return confirm('<?php echo e(__('هل انت متاكد ؟')); ?>')"  class="btn btn-danger "><i class="fas fa-trash-alt"></i>  حذف  الصورة </buttn>
              </form>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>لم تقم برفع تصاميم للقالب</p>
        <?php endif; ?>
      </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.adminLTE', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>