<?php $__env->startSection('title','العملاء'); ?>
<?php $__env->startSection('content'); ?>


<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <!-- Strat MSG -->
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert" id="display-success">
     <strong><?php echo e(session()->get('success')); ?></strong>
     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
  <div class="alert-dismissible  alert alert-danger" id="display-success">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>
  <!-- End MSG -->
<div class="row">
    <div class="card mt-4 text-center">
        <div class="card-header">

        <form action="<?php echo e(route('user.search')); ?>" method="post" onsubmit="return false">
            <?php echo csrf_field(); ?>
            <input class="form-control form-control"  id="search" name="search" type="search" placeholder="بحث عن عميل" aria-label="Search" >
        </form>



        <a href="<?php echo e(route('user.create')); ?>" class="btn btn-success btn-block mt-4"><i class="fas fa-user"></i> اضافة عميل  </a>
    </div>
    <!-- /.card-header -->
    <div class="card-body table-responsive-sm">
      <table class="table  table-bordered table-striped">
        <thead>
            <tr>
              <th>#</th>
              <th>اسم العميل</th>
              <th>نوع الباقة</th>
              <th>المتبقي على الاشتراك</th>
              <th>حالة العميل</th>
              <th>تحكم</th>
          </tr>
      </thead>
      <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kay=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <tr>
            <td><?php echo e($kay+1); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e(isset($user->Subscrip) ? $user->Subscrip->PakageName : 'لم يشترك'); ?></td>
            <td>-</td>
            <td><?php echo e($user->Append == 1 ? "مغعل" : "محظور"); ?></td>
            <td>

                <a href="<?php echo e(route('user.edit',$user->id)); ?>" class="btn btn-info "><i class="fas fa-edit"></i></a>


                <form method="post" action="<?php echo e(route('user.destroy',$user->id)); ?>" style="display: inline-block;">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button onclick="return confirm('<?php echo e(__('هل انت متاكد ؟')); ?>')" class="btn btn-danger "><i class="fas fa-trash-alt"></i></buttn>
                  </form>

            </td>
        </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="alert alert-danger  fade show" role="alert">
     <h4>ليس هناك اي عملاء حتى الان</h4>
     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    </div>
       <a href="<?php echo e(route('user.create')); ?>" class="btn btn-info mb-4"><i class="fas fa-plus"></i> اضافة عميل </a>

<?php endif; ?>
</tbody>
<tfoot>

</tfoot>
</table>
</div>
<!-- /.card-body -->
</div>
<!-- /.card -->

<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin.layouts.adminLTE', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>