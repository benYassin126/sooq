<?php $__env->startSection('title','القوالب'); ?>
<?php $__env->startSection('content'); ?>


<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <!-- Strat MSG -->
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert" id="display-success">
     <strong><?php echo e(session()->get('success')); ?></strong>
     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
  <div class="alert-dismissible  alert alert-danger" id="display-success">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>
  <!-- End MSG -->


  <!-- Start Content -->
  <br>
  <h4 class="text-center mb-4">قوالب النظام</h4>
  <br>
    <a href="<?php echo e(route('template.create')); ?>" class="btn btn-success btn-block mb-4">إضافة قالب</a>
  <div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $allTemplates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col col-4">
        <div class="card">
            <div class="card-header text-center">
                <a href="<?php echo e(route('template.show',$template->id)); ?>">  <?php echo e($template->TemplateName); ?> </a>
            </div>
            <div class="card-body">
                <a href="<?php echo e(route('template.show',$template->id)); ?>"> <img class="card-img-top" src="template/fetch_image/<?php echo e($template->id); ?>"></a>
            </div>
            <div class="card-footer"><a href="<?php echo e(route('template.show',$template->id)); ?>" class="btn btn-primary btn-block">إدارة القالب</a></div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class=" alert alert-danger">
        <p>لا توجد قوالب لعرضها</p>
    </div>

<?php endif; ?>

    </div>

  </div>


  <!-- End Content -->

  <?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.adminLTE', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>