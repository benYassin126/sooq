
<div class="container">
    <div class="row justify-content-center">

 <div class="allImg">
      <div class="row">

        <?php $__empty_1 = true; $__currentLoopData = $allUserDesigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col col-sm-12 col-md-6 col-lg-3">
          <div class="card mb-2">
            <div class="card-body">
              <img style="width: 200px; height: 200px;" src="<?php echo e(url('home/fetch_image')); ?>/<?php echo e($img->id); ?>">
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>لم تقم برفع تصاميم للقالب</p>
        <?php endif; ?>
      </div>
    </div>
    </div>
</div>

