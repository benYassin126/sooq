<?php $__env->startSection('content'); ?>
<div class="login-box">
  <div>
    <h5 class="text-center "><?php echo e(__('Register')); ?></h5>
  </div>
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">

      <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>
        <div class="input-group mb-3">
          <input  id="name" type="text" name="name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name')); ?>"  value="<?php echo e(old('name')); ?>" required autofocus>

          <div class="input-group-append">
            <span class="input-group-text"> <i class="fa fa-user"></i></span>
          </div>

          <?php if($errors->has('name')): ?>
          <span class="invalid-feedback" role="alert">
            <strong><?php echo e($errors->first('name')); ?></strong>
          </span>
          <?php endif; ?>
        </div>

        <div class="input-group mb-3">
          <input  id="email" type="email" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('E-Mail Address')); ?>"  value="<?php echo e(old('email')); ?>" required>

          <div class="input-group-append">
            <span class="input-group-text"> <i class="fa fa-envelope"></i></span>
          </div>

          <?php if($errors->has('email')): ?>
          <span class="invalid-feedback" role="alert">
            <strong><?php echo e($errors->first('email')); ?></strong>
          </span>
          <?php endif; ?>
        </div>

        <div class="input-group mb-3">
          <input  id="password" type="password" name="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Password')); ?>" required autofocus>
          <div class="input-group-append">
            <span class=" input-group-text"><i class="fa fa-lock"></i></span>
          </div>

          <?php if($errors->has('password')): ?>
          <span class="invalid-feedback" role="alert">
            <strong><?php echo e($errors->first('password')); ?></strong>
          </span>
          <?php endif; ?>
        </div>


        <div class="input-group mb-3">
          <input  id="password" type="password" name="password_confirmation" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Confirm Password')); ?>"   required autofocus>
          <div class="input-group-append">
            <span class=" input-group-text"> <i class="fa fa-lock"></i></span>
          </div>
        </div>

        <div class="row">
         <!-- /.col -->
         <div class="div-center">
          <button type="submit" class="btn btn-primary">  <?php echo e(__('Register')); ?></button>
        </div>
        <!-- /.col -->
      </div>
    </form>

  </div>
  <!-- /.login-card-body -->
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>