<?php $__env->startSection('title','الملف الشخصي'); ?>
<?php $__env->startSection('content'); ?>
<!-- Main content -->
<div class="content">
  <div class="container-fluid">
        <!-- Strat MSG -->
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert" id="display-success">
            <strong><?php echo e(session()->get('success')); ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert-dismissible  alert alert-danger" id="display-success">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
    <!-- Strat MSG -->
    <br>
    <div class="card card-info mt-4 mb-4">
      <div class="card-header">
        <h3 class="card-title" style="display: inline-block;">ملفك الشخصي</h3>
      </div>
      <div class="card-body">
        <form action="<?php echo e(route('profile')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
  <div class="form-group">
    <label class="control-label">اسم   الكريم</label>
    <div>
      <input type="text" class="form-control"  placeholder="اسمك"  autofocus name="name"  <?php if(isset($user)): ?> value="<?php echo e($user->name); ?>" <?php endif; ?> required >
  </div>
</div>

<div class="form-group">
    <label class="control-label">ايميلك</label>
    <div>
      <input type="email" class="form-control"  placeholder="الايميل"   name="email"  <?php if(isset($user)): ?> value="<?php echo e($user->email); ?>" <?php endif; ?> required >
  </div>
</div>

<div class="form-group">
    <label class="control-label">الرقم السري</label>
    <div>
      <input type="password" class="form-control"   name="password" >
  </div>
</div>

<div class="form-group">
    <label class="control-label">حسابك في تويتر</label>
    <div>
      <input type="text" class="form-control"  placeholder="Twitter"   name="Twitter"  <?php if(isset($user)): ?> value="<?php echo e($user->Twitter); ?>" <?php endif; ?>  >
  </div>
</div>


<div class="form-group">
    <label class="control-label">حسابك في الانستقرام</label>
    <div>
      <input type="text" class="form-control"  placeholder="Instagram"   name="Instagram"  <?php if(isset($user)): ?> value="<?php echo e($user->Instagram); ?>" <?php endif; ?>  >
  </div>
</div>

<div class="form-group">
    <label class="control-label">لون الهوية الاساسي  (Hex)</label>
    <div>
       <input type="color" name="MineColor"<?php echo e(isset($user) ? 'value=' . $user->MineColor .'': 'value=#010101'); ?> >
   </div>
</div>


<div class="form-group mb-2">
    <label class="control-label ">لون الهوية الثانوي (Hex)</label>
    <div>
       <input type="color" name="SubColor" <?php echo e(isset($user) ? 'value=' . $user->SubColor .'' : 'value=#010101'); ?>>
   </div>
</div>

        </div>
        <div class="card-footer">
          <button type="submit" name="update" class="btn btn-success btn-block"> <i class="fas fa-edit fa-sm"></i> حفظ التعديلات  </button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.userLTE', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>