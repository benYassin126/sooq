
//Function to send form without refresh page
function post()
{
    $.ajaxSetup({
  headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  }
});
  var msg = document.getElementById("msg").value;
  if(msg)
  {

    $.ajax
    ({
      type: 'post',
      url: '/try.submit',
      data:
      {
         Nots:msg,

      },
      success: function (response)
      {
      document.getElementById("status").innerHTML="طلبك وصل بإذن الله التصميم الجاي بحاول يكون زي ماتبي";
    //  $("#colse").delay(5000).click();
      setTimeout(function(){
         $('#exampleModal2').modal('hide')
    }, 5000);
      }
    });
  }else {
    document.getElementById("status").innerHTML="الحقل مطلوب";
  }


  return false;
}

//Hidde Submit Form After Send data

$('#changeTemplateForm').one('submit', function() {
    $(this).find('input[type="submit"]').attr('disabled','disabled');
});




$("#changeTemplateForm,#tryForm,#ColorsForm").on("submit", function(){
    $("#pageloaderWhenDesign").fadeIn();
  });//submit

$("#uploadImgsForm,#registerForm,#a3tmed").on("submit", function(){
    $("#pageloader").fadeIn();
  });//submit



function CheckBusinessType(val){
 var OtherBusinessTypeElement=document.getElementById('OtherBusinessType');
 if(val=='others'){
   OtherBusinessTypeElement.style.display='block';
   OtherBusinessTypeElement.setAttribute("required", "required");
}
 else{
   OtherBusinessTypeElement.style.display='none';
  OtherBusinessTypeElement.removeAttribute("required");
  OtherBusinessTypeElement.value = '';

    val ='';
}

}

function CheckPhoneType(val){
 var inst = document.getElementById('inst');
 var tweet = document.getElementById('tweet');
 if(val=='tweet'){
   tweet.style.display='block';
   inst.style.display='none';
}
 else{
   inst.style.display='block';
   tweet.style.display='none';
}

}

function replaceColor(){

 var MineColor = document.getElementById('MineColor');
 var SubColor = document.getElementById('SubColor');
 let TempColor;
 TempColor = MineColor.value;

MineColor.value = SubColor.value;
SubColor.value = TempColor;

}


function defultColor(){

 var MineColor = document.getElementById('MineColor');
 var SubColor = document.getElementById('SubColor');
 var TempColor = SubColor.value;


    SubColor.value = "#010101";
MineColor.value =  "#010101";



}


$(function(){
  $('.fa-minus,.chatbox-top,.a3tmed').click(function(){ $('.fa-minus').closest('.chatbox').toggleClass('chatbox-min');
  });
});

$(function() {

    "use strict";

    //===== Prealoder

    $(window).on('load', function(event) {
        $('.preloader').delay(500).fadeOut(500);
    });


    //===== Mobile Menu

    $(".navbar-toggler").on('click', function() {
        $(this).toggleClass('active');
    });

    $(".navbar-nav a").on('click', function() {
        $(".navbar-toggler").removeClass('active');
    });


    //===== close navbar-collapse when a  clicked

    $(".navbar-nav a").on('click', function () {
        $(".navbar-collapse").removeClass("show");
    });


    //===== Sticky

    $(window).on('scroll',function(event) {
        var scroll = $(window).scrollTop();
        if (scroll < 10) {
            $(".navigation-bar").removeClass("sticky");
        }else{
            $(".navigation-bar").addClass("sticky");
        }
    });




    //===== wow

    new WOW().init();


    //===== AOS

     AOS.init({
         duration: 800,
     });


    //===== Slick project

    $('.project-active').slick({
        dots: true,
        infinite: true,
        speed: 800,
        slidesToShow: 5,
        slidesToScroll: 3,
        arrows: false,
        responsive: [
            {
              breakpoint: 1200,
              settings: {
                slidesToShow: 4,
              }
            },
            {
              breakpoint: 992,
              settings: {
                slidesToShow: 3,
              }
            },
            {
              breakpoint: 768,
              settings: {
                slidesToShow: 2,
              }
            },
            {
              breakpoint: 576,
              settings: {
                slidesToShow: 1,
              }
            }
        ]
    });


    //===== Slick Testimonial

    $('.testimonial-active').slick({
        dots: true,
        infinite: true,
        speed: 800,
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
    });


    //===== Back to top

    // Show or hide the sticky footer button
    $(window).on('scroll', function(event) {
        if($(this).scrollTop() > 600){
            $('.back-to-top').fadeIn(200)
        } else{
            $('.back-to-top').fadeOut(200)
        }
    });

    //Animate the scroll to yop
    $('.back-to-top').on('click', function(event) {
        event.preventDefault();

        $('html, body').animate({
            scrollTop: 0,
        }, 1500);
    });








});
