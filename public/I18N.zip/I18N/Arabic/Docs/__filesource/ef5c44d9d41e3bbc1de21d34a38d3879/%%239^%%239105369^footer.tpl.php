<?php /* Smarty version 2.6.0, created on 2016-01-01 10:11:26
         compiled from footer.tpl */ ?>
        <div class="credit">
		    <hr />
		    Documentation generated on <?php echo $this->_tpl_vars['date']; ?>
 by <a href="<?php echo $this->_tpl_vars['phpdocwebsite']; ?>
">phpDocumentor <?php echo $this->_tpl_vars['phpdocversion']; ?>
</a>
	      </div>
      </td></tr></table>
    </td>
  </tr>
</table>

</body>
</html>